﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionBodiedFunction
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstName = "sss";
            string lastName = "aaa";
            Person person = new Person(firstName,lastName);
            // person.ToString();

            person.display();
        }
    }
}
