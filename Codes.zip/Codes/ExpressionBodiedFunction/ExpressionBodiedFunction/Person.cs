﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionBodiedFunction
{
   public class Person
    {
       public  Person(string fname,string lname)
        {
            FirstName = fname;
            LastName = lname;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override string ToString() => $"{FirstName},{LastName}";

        public void display() => Console.WriteLine(ToString());
        
    }
}
