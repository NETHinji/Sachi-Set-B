﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Employee.Entity;
using Employee.Exception;

namespace Employee.DAL
{
    public class EmployeeDAL
    {
        public static List<EmployeeEntity> employees = new List<EmployeeEntity>();
        public bool AddDAL(EmployeeEntity employeeEntity)
        {

            bool IsEmployeeAdded = false;
            try
            {
                employees.Add(employeeEntity);
                IsEmployeeAdded = true;

            }
            catch (EmployeeException)
            {
                Console.WriteLine("Error at DAL");
                throw;

            }
            return IsEmployeeAdded;

        }
        public List<EmployeeEntity> GetAllEmployeeDAL()
        {
            return employees;
        }

    } 
}
