﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Employee.DAL;
using Employee.Entity;

namespace Employee.BL
{
    public class EmployeeBl
    {
       static List<EmployeeEntity> employees = new List<EmployeeEntity>();
        public bool AddBl(EmployeeEntity employeeEntity)
        {
            bool IsvalidEmp = false;
            

            IsvalidEmp = Isvalid(employeeEntity);
            if (IsvalidEmp)
            {
                EmployeeDAL employeeDAL = new EmployeeDAL();
                bool Valid= employeeDAL.AddDAL(employeeEntity);
                return Valid;
            }
            else
            {
                return IsvalidEmp;
            }

        }
        public static List<EmployeeEntity> ShowBL(EmployeeEntity employeeEntity)
        {
           
            EmployeeDAL employeeDAL = new EmployeeDAL();
            employees = employeeDAL.GetAllEmployeeDAL();
            return employees;
        }

        private bool Isvalid(EmployeeEntity employeeEntity)
        {
            bool Valid = true;
            Regex regex = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
            bool IsVAlidEmail = regex.IsMatch(employeeEntity.Email);
            Regex regex1 = new Regex(@"[9|0-9]");
            bool IsValidContact = regex1.IsMatch(employeeEntity.ContactNumber.ToString());

            Regex regex2 = new Regex(@"[A-Za-z]");
            bool IsValidName = regex1.IsMatch(employeeEntity.EmpName);

            if(IsValidName && IsValidContact && IsVAlidEmail)
            {
                Valid = true;
                return Valid;
            }
            else
            {
                return Valid;
            }

           
        }
    }
}
