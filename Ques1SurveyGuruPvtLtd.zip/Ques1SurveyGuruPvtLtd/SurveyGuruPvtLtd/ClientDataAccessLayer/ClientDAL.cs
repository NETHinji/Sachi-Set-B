﻿using ClientEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientExceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ClientDataAccessLayer
{
	public class ClientDAL
	{
		public static List<Client> voterList = new List<Client>();

		public bool AddVoterDAL(Client newVisitor)
		{
			bool voterAdded = false;
			try
			{
				voterList.Add(newVisitor);



				voterAdded = true;
			}
			catch (SystemException ex)
			{
				throw new ClientException(ex.Message);
			}
			return voterAdded;
		}

		public Client SearchVoterDAL(string searchVoter)
		{
			Client voterSearch = null;
			try
			{
				voterSearch = voterList.Find(visitor => visitor.VoterId == searchVoter);
			}
			catch (SystemException ex)
			{
				throw new ClientException(ex.Message);
			}
			return voterSearch;
		}



		public List<Client> GetAllVoterDAL()
		{

			return voterList;

		}

		public static void SerializeData(List<Client> v1)
		{
			FileStream fileStream = new FileStream("ser.dat", FileMode.Create);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Serialize(fileStream, v1);
			fileStream.Close();
		}

		public static void DeserializeData()
		{
			FileStream fileStream = new FileStream("ser.dat", FileMode.Open);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			List<Client> e1 = (List<Client>)binaryFormatter.Deserialize(fileStream);
			fileStream.Close();

		}
	}
}
