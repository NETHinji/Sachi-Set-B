﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientEntities;
using ClientBuisnessLogic;
using ClientExceptions;
using ClientDataAccessLayer;
using System.IO;

namespace ClientPresentation
{
	class Program
	{

		List<Client> voterList = new List<Client>();

		static void Main(string[] args)
		{



			int choice;
			do
			{
				if (File.Exists("ser.dat"))
					ClientDAL.DeserializeData();
				PrintMenu();
				Console.WriteLine("Enter your Choice:");
				choice = Convert.ToInt32(Console.ReadLine());

				switch (choice)
				{
					case 1:

						AddClient();
						break;
					case 2:
						ListAllClient();
						break;
					case 3:
						SearchClientByID();
						break;


					case 4:

						return;
					default:
						Console.WriteLine("Invalid Choice");
						break;


				}

			} while (choice != -1);
		}

		private static void SearchClientByID()
		{
			try
			{
				string searchVoterID;
				Console.WriteLine("Enter Voter ID to Search:");
				searchVoterID = Console.ReadLine();
				Client searchVoter = ClientBLL.SearchClientBLL(searchVoterID);
				if (searchVoter != null)
				{
					Console.WriteLine("\t\t\t******************************************************************************");
					Console.WriteLine("VoterID\t\tName\t\tWard\t\tCity\t\tState\t\tPartytoVote\t\tReason");
					Console.WriteLine("\t\t\t******************************************************************************");
					Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", searchVoter.VoterId, searchVoter.VoterName,
                                        searchVoter.Ward, searchVoter.City, searchVoter.State, searchVoter.PartyToVoteFor, searchVoter.ReasonToVote);

					Console.WriteLine("\t\t\t******************************************************************************");
				}
				else
				{
					Console.WriteLine("No Voter Details Available");
				}

			}
			catch (ClientException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}

		private static void AddClient()
		{
			try
			{
				List<Client> voterList = new List<Client>();
				Client newVoter = new Client();

				Random rn = new Random();
				Console.WriteLine("Enter Voter ID :");
                newVoter.VoterId = Console.ReadLine();
				Console.WriteLine("Enter Voter Name :");
                newVoter.VoterName = Console.ReadLine();

                newVoter.State = "Karnataka";
				Console.WriteLine("Enter the city\n 0.Bangalore \t 1.Mysore \t 2.Hubli");
                newVoter.City = (Client.eCity)(Convert.ToInt32(Console.ReadLine()));
				Console.WriteLine("Enter the ward\n 0.North \t 1.South \t 2.East \t 3.West");
                newVoter.Ward = (Client.eWard)(Convert.ToInt32(Console.ReadLine()));
				Console.WriteLine("Enter the Party to vote for \n 0.Congress \t 1.BJP \t 2.JD");
                newVoter.PartyToVoteFor = (Client.PartyToVote)(Convert.ToInt32(Console.ReadLine()));
				Console.WriteLine("Enter the reason");
                newVoter.ReasonToVote = Console.ReadLine();

				bool voterAdded = ClientBLL.AddClientBLL(newVoter);
				if (voterAdded)
					Console.WriteLine("Voter Added");
				else
					Console.WriteLine("Voter not Added");
				ClientDAL.SerializeData(voterList);
			}
			catch (ClientException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}


		private static void ListAllClient()
		{
			try
			{
				
				List<Client> voterList = ClientBLL.GetAllVoterBLL();
				if (voterList != null)
				{
					Console.WriteLine("\t\t\t******************************************************************************");
					Console.WriteLine("VoterID\t\tName\t\tWard\t\tCity\t\tState\t\tPartytoVote\t\tReason");
					Console.WriteLine("\t\t\t******************************************************************************");
					foreach (Client voter in voterList)
					{
						Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", voter.VoterId, voter.VoterName,
                                        voter.Ward, voter.City, voter.State, voter.PartyToVoteFor, voter.ReasonToVote);
					}
					Console.WriteLine("\t\t\t******************************************************************************");

				}
				else
				{
					Console.WriteLine("No Voter Details Available");
				}
			}
			catch (ClientException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}


		private static void PrintMenu()
		{
			Console.WriteLine("\n*********** Voter Menu***********");
			Console.WriteLine("1. Add Voter");
			Console.WriteLine("2. List All Voters");
			Console.WriteLine("3. Search  by Voter ID");
			Console.WriteLine("4. Exit");
			Console.WriteLine("******************************************\n");

		}
	}
}
