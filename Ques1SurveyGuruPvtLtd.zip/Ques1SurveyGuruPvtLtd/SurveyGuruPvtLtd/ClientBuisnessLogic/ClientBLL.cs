﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientDataAccessLayer;
using ClientEntities;
using ClientExceptions;

namespace ClientBuisnessLogic
{
	public class ClientBLL
	{
		private static bool ValidateClient(Client voter)
		{
			StringBuilder sb = new StringBuilder();
			bool validVoter = true;
			string x = voter.VoterId.Substring(0, 2);
			string y = voter.VoterId.Substring(2, 4);
			if (x.All(Char.IsLower)||!y.All(Char.IsNumber))
			{
                validVoter = false;
				sb.Append(Environment.NewLine + "Invalid Voter ID");

			}
			if (voter.VoterName == string.Empty)
			{
                validVoter = false;
				sb.Append(Environment.NewLine + "Voter Name Required");

			}
			if((int)voter.Ward>3)
			{
                validVoter = false;
				sb.Append(Environment.NewLine + "Invalid Ward");
			}
			if ((int)voter.PartyToVoteFor > 2)
			{
                validVoter = false;
				sb.Append(Environment.NewLine + "Invalid Party");
			}
			if (voter.ReasonToVote.Length>200)
			{
                validVoter = false;
				sb.Append(Environment.NewLine + "ReasonToVote should be less than 200");
			}

			if (validVoter == false)
				throw new ClientException(sb.ToString());
			return validVoter;
		}



		public static Client SearchClientBLL(string searchVoterID)
		{
			Client searchVoter = null;
			try
			{
				ClientDAL clientDAL = new ClientDAL();
				searchVoter = clientDAL.SearchVoterDAL(searchVoterID);
			}
			catch (ClientException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return searchVoter;
		}


		public static bool AddClientBLL(Client newVoter)
		{
			bool voterAdded = false;
			try
			{
				if (ValidateClient(newVoter))
				{
					ClientDAL voterDAL = new ClientDAL();
                    voterAdded = voterDAL.AddVoterDAL(newVoter);
				}
			}
			catch (ClientException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw ex;
			}

			return voterAdded;
		}

		public static List<Client> GetAllVoterBLL()
		{
			List<Client> voterList = null;
			try
			{
				ClientDAL clientDAL = new ClientDAL();
				voterList = clientDAL.GetAllVoterDAL();
			}
			catch (ClientException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return voterList;
		}
	}
}
