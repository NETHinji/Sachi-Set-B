﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using BusinessLayer;
using Exceptions;


namespace GuestPhoneBookPractice
{
    class Program
    {
        static void Main(string[] args)
        {

            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddEmployee();
                        break;
                    case 2:
                        ListAllEmployee();
                        break;
                    case 3:
                        SearchEmployeeByID();
                        break;
                    case 4:
                        UpdateEmployee();
                        break;
                    case 5:
                        DeleteEmployee();
                        break;
                    case 6:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (choice != -1);
        }

        private static void DeleteEmployee()
        {
            try
            {
                int deleteEmployeeID;
                Console.WriteLine("Enter EmployeeID to Delete:");
                deleteEmployeeID = Convert.ToInt32(Console.ReadLine());
                Employee deleteEmployee = EmployeeBL.SearchEmployee(deleteEmployeeID);
                if (deleteEmployee != null)
                {
                    bool employeedeleted = EmployeeBL.DeleteEmployee(deleteEmployeeID);
                    if (employeedeleted)
                        Console.WriteLine("Employee Deleted");
                    else
                        Console.WriteLine("Employee not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdateEmployee()
        {
            try
            {
                int updateEmployeeID;
                Console.WriteLine("Enter EmployeeID to Update Details:");
                updateEmployeeID = Convert.ToInt32(Console.ReadLine());
                Employee updatedEmployee = EmployeeBL.SearchEmployee(updateEmployeeID);
                if (updatedEmployee != null)
                {
                    Console.WriteLine("Update Employee Name :");
                    updatedEmployee.EmployeeName = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedEmployee.EmployeeContactNumber = Console.ReadLine();
                    Console.WriteLine("Update Designation :");
                    updatedEmployee.EmployeeDesignation = Console.ReadLine();
                    Console.WriteLine("Update city name");
                    updatedEmployee.citylist = Console.ReadLine();
                    bool employeeUpdated = EmployeeBL.UpdateEmployee(updatedEmployee);
                    if (employeeUpdated)
                        Console.WriteLine("Employee Details Updated");
                    else
                        Console.WriteLine("Employee Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }


            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchEmployeeByID()
        {
            try
            {
                int searchEmployeeID;
                Console.WriteLine("Enter EmployeeID to Search:");
                searchEmployeeID = Convert.ToInt32(Console.ReadLine());
                Employee searchEmployee = EmployeeBL.SearchEmployee(searchEmployeeID);
                if (searchEmployee != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber\t\tDesignation\t\tCity");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", searchEmployee.EmployeeID, searchEmployee.EmployeeName, searchEmployee.EmployeeContactNumber,searchEmployee.EmployeeDesignation,searchEmployee.citylist);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }

            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllEmployee()
        {
            try
            {
                List<Employee> employeeList = EmployeeBL.GetAllEmployee();
                if (employeeList != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("GuestID\t\tName\t\tPhoneNumber\t\tDesignation\t\tCity");
                    Console.WriteLine("******************************************************************************");
                    foreach (Employee employee in employeeList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", employee.EmployeeID, employee.EmployeeName, employee.EmployeeContactNumber,employee.EmployeeDesignation,employee.citylist);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Employee Details Available");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddEmployee()
        {
            try
            {
                Employee newEmployee = new Employee();
                Console.WriteLine("Enter EmployeeID :");
                newEmployee.EmployeeID = Console.ReadLine();
                Console.WriteLine("Enter Employee Name :");
                newEmployee.EmployeeName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newEmployee.EmployeeContactNumber = Console.ReadLine();
                Console.WriteLine("Enter Designation :");
                newEmployee.EmployeeDesignation = Console.ReadLine();
                Console.WriteLine("Enter city name");
                newEmployee.citylist = Console.ReadLine();
                bool employeeAdded = EmployeeBL.AddEmployee(newEmployee);
                if (employeeAdded)
                    Console.WriteLine("Employee Added");
                else
                    Console.WriteLine("Employee not Added");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Employee Details Menu***********");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. List All Employee");
            Console.WriteLine("3. Search Employee by ID");
            Console.WriteLine("4. Update Employee");
            Console.WriteLine("5. Delete Employee");
            Console.WriteLine("6. Exit");
            Console.WriteLine("******************************************\n");

        }
    }

}
