﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using Exceptions;
using DataAccessLayer;


namespace BusinessLayer
{
    public class EmployeeBL
    {
        private static bool ValidateEmployee(Employee employee)
        {
            StringBuilder sb = new StringBuilder();
            string x = employee.EmployeeID.Substring(1, 4);
            bool validEmployee = true;
            if ((employee.EmployeeID.IndexOf('C')!=0 || !x.All(char.IsDigit)))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid Id");
            }
         
            if (employee.EmployeeName == string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Employee Name Required");

            }
            if (employee.EmployeeContactNumber.Length < 10)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (!(System.Text.RegularExpressions.Regex.IsMatch(employee.EmployeeContactNumber, "([8-9]{1}[0-9]{9})")))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Should start with 8 and 9");
            }
            if(employee.EmployeeDesignation==string.Empty)
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Designation required");
            }
            if (!(employee.citylist.Equals(Employee.Citylist.Hyderbad)) && !(employee.citylist.Equals(Employee.Citylist.Kolkata)) && !(employee.citylist.Equals(Employee.Citylist.Pune)))
            {
                validEmployee = false;
                sb.Append(Environment.NewLine + "Invalid City");
            }
                if (validEmployee == false)
                throw new EmployeeException(sb.ToString());
            return validEmployee;
        }

        public static bool AddEmployee(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                if (ValidateEmployee(newEmployee))
                {
                    EmployeeDLL employeeDLL = new EmployeeDLL();
                    employeeAdded = employeeDLL.AddEmployee(newEmployee);
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeAdded;
        }

        public static List<Employee> GetAllEmployee()
        {
            List<Employee> employeeList = null;
            try
            {
                EmployeeDLL employeeDLL = new EmployeeDLL();
                employeeList = employeeDLL.GetAllEmployee();
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employeeList;
        }

        public static Employee SearchEmployee(int searchEmployeeID)
        {
            Employee searchEmployee = null;
            try
            {
                EmployeeDLL employeeDLL = new EmployeeDLL();
                searchEmployee = employeeDLL.SearchEmployee(searchEmployeeID);
            }
            catch (EmployeeException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchEmployee;

        }

        public static bool UpdateEmployee(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                if (ValidateEmployee(updateEmployee))
                {
                    EmployeeDLL employeeDLL = new EmployeeDLL();
                    employeeUpdated =employeeDLL .UpdateEmployee(updateEmployee);
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeUpdated;
        }

        public static bool DeleteEmployee(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                if (deleteEmployeeID > 0)
                {
                    EmployeeDLL employeeDLL = new EmployeeDLL();
                    employeeDeleted = employeeDLL.DeleteEmployee(deleteEmployeeID);
                }
                else
                {
                    throw new EmployeeException("Invalid Employee ID");
                }
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return employeeDeleted;
        }

    }
}
