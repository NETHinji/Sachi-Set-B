﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Entities;
using Exceptions;

namespace DataAccessLayer
{
    public class EmployeeDLL
    {
        public static List<Employee> employeeList = new List<Employee>();

        public bool AddEmployee(Employee newEmployee)
        {
            bool employeeAdded = false;
            try
            {
                employeeList.Add(newEmployee);
                employeeAdded = true;
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeAdded;

        }

        public List<Employee> GetAllEmployee()
        {
            return employeeList;
        }

        public Employee SearchEmployee(int searchEmployeeID)
        {
            Employee searchemployee = null;
            try
            {
                searchemployee = employeeList.Find(guest => guest.EmployeeID.Equals(searchEmployeeID));
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return searchemployee;
        }

        public bool UpdateEmployee(Employee updateEmployee)
        {
            bool employeeUpdated = false;
            try
            {
                for (int i = 0; i < employeeList.Count; i++)
                {
                    if (employeeList[i].EmployeeID == updateEmployee.EmployeeID)
                    {
                        updateEmployee.EmployeeName = employeeList[i].EmployeeName;
                        updateEmployee.EmployeeContactNumber = employeeList[i].EmployeeContactNumber;
                        updateEmployee.EmployeeDesignation = employeeList[i].EmployeeDesignation;
                        updateEmployee.citylist = employeeList[i].citylist;
                        employeeUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeUpdated;

        }

        public bool DeleteEmployee(int deleteEmployeeID)
        {
            bool employeeDeleted = false;
            try
            {
                Employee deleteEmployee = employeeList.Find(employee => employee.EmployeeID.Equals(deleteEmployeeID));

                if (deleteEmployee != null)
                {
                   employeeList.Remove(deleteEmployee);
                    employeeDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new EmployeeException(ex.Message);
            }
            return employeeDeleted;

        }

    }
}
