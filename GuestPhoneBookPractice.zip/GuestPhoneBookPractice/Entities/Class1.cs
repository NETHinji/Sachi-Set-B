﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Employee
    {
        private string employeeID;

        public string EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }
        private string employeeName;

        public string EmployeeName
        {
            get { return employeeName; }
            set { employeeName = value; }
        }
        private string employeeContactNumber;

        public string EmployeeContactNumber
        {
            get { return employeeContactNumber; }
            set { employeeContactNumber = value; }
        }

        private string employeeDesignation;

        public string EmployeeDesignation
        {
            get { return employeeDesignation; }
            set { employeeDesignation = value; }
        }

        public enum Citylist { Kolkata,Pune,Hyderbad}
        public string citylist { get; set; }

        public Employee()
        {
            employeeID = string.Empty;
           employeeName = string.Empty;
          employeeContactNumber = string.Empty;
            employeeDesignation = string.Empty;
            citylist = string.Empty;

        }
    }
}
