﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using SagarMarket.DataAccessLayer;
using SagarMarket.Entity;

namespace sagarMarket.Businesslayer
{
    public class DealerBl
    {
        public static List<string> ProductList = new List<string>() {"Grocery","Bakery_Products","vegetables","fruits" };
        public DealerBl()
        {
        }

        public bool AddVisit(Dealer dealer)
        {
            bool dealerAdded = false;
            try
            {
                if (ValidateDealerr(dealer))
                {
                    DealerDL ddlL = new DealerDL();
                    dealerAdded = ddlL.AddVisitor(dealer);
                }
            }
            catch (Exception)
            {

                throw;
            }
            return dealerAdded;
        }

        private bool ValidateDealerr(Dealer dealer)
        {
            bool validDealer = true;
            try
            {
                if (dealer.Dealername == string.Empty)
                {
                    validDealer = false;
                    Console.WriteLine("Visitor Name Required");

                }
                if (dealer.DealerAddress == string.Empty)
                {
                    validDealer = false;
                    Console.WriteLine("Visitor Address Required");

                }
                if (dealer.dealerPhoneNo.Length != 10)
                {
                    validDealer = false;
                    Console.WriteLine("Mobile number shoult be of 10-digit");
                }

                if (!(Regex.IsMatch(dealer.dealerPhoneNo, "([7-9]{1}[0-9]{9})")))
                {
                    validDealer = false;
                    Console.WriteLine("Mobile number should start with 8 or 9");
                }



                if (!(Regex.IsMatch(dealer.DealerEmailId, @"([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)
                   |(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)")))
                {
                    validDealer = false;
                    Console.WriteLine("Invalid email number");
                }

                if (!(Regex.IsMatch(dealer.DealerId, "([D]{1}[L]{1}[0-9]{4})")))
                {
                    validDealer = false;
                    Console.WriteLine("Dealer ID should be of 6 character and Start with DL, followed by Digits");
                }

            }
            catch (Exception)
            {

                throw;
            }
            return validDealer;
        }

        public List<Dealer> SearchDealer(string product)
        {
            List<Dealer> dealerEntities = new List<Dealer>();
            try
            {
                DealerDL dealerDAL = new DealerDL();
               
                dealerEntities = dealerDAL.SearchDealerDAL(product);
               
            }
            catch (Exception ex)
                {
                    throw ex;
                }
            return dealerEntities;

        }
            
        }
    }
