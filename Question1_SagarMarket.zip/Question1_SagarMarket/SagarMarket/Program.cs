﻿using sagarMarket.Businesslayer;
using SagarMarket.Entity;
using SagarMarket.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SagarMarket.Presentationlayer
{
    class Program
    {
        static void Main(string[] args)
        {
            string Continue;
            do
            {

                Console.WriteLine("1.Add Dealer\n2.Search Dealer\n3.Exit");
                int ch;
                Console.Write("\nEnter Operation to do: ");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        AddCustomer();
                        break;
                    case 2:
                        SearchCustomer();
                        break;
                    case 3:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }
                Console.Write("\nDo You Want To Continue? (Y/N) : ");
                Continue = Console.ReadLine();
            } while (Continue != "N" && Continue != "n");
        }

       

        private static void AddCustomer()
        {

            try
            {
                Dealer dealer = new Dealer();

                Console.Write("Enter Dealer ID: ");
                dealer.DealerId = Console.ReadLine();

                Console.Write("Enter Dealer Name: ");
                dealer.Dealername = Console.ReadLine();

                Console.Write("Enter dealer address: ");
                dealer.DealerAddress = Console.ReadLine();

                Console.Write("Enter Dealer email id: ");
                dealer.DealerEmailId = Console.ReadLine();

                Console.Write("enter Dealer Mobile Number: ");
                dealer.dealerPhoneNo = Console.ReadLine();

                Console.Write("Enter Dealer Status number: ");
                Console.WriteLine("\n1.Active\n2.InActive");
                int i = Convert.ToInt32(Console.ReadLine());
                dealer.DealerStatus = (Dealer.DealerStatus1)i;

                Console.Write("enter dealer product number ");
                Console.WriteLine("\n1.Grocery\n2.Bakery product\n3.Vegetables\n4.fruits");
                int j = Convert.ToInt32(Console.ReadLine());
                dealer.DealerProductCategory =(Dealer.ProductCategory1)j;

                DealerBl dbl = new DealerBl();
                bool dealerAdded = dbl.AddVisit(dealer);
                if (dealerAdded)
                {
                    Console.WriteLine("Visitor Added  " + dealer.DealerId);
                }
                else
                {
                    Console.WriteLine("Visitor not Added");
                }

            }
            catch (System.Exception)
            {

                throw;
            }


        }

        private static void SearchCustomer()
        {
            try
            {
                string Category;
                Console.WriteLine("Enter Category to Search:");
                Category = Console.ReadLine();
                //int c = 0;
                DealerBl bl = new DealerBl();
                List<Dealer> dealers1 = bl.SearchDealer(Category);
                Console.WriteLine(dealers1.Count);
                foreach (var item in dealers1)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("DealerId\t DealerName\t DealerAddress\t DealerEmailID\t Dealer Phone Number\t Dealer Status\t Dealer Category");
                    Console.WriteLine("******************************************************************************");


                   // Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}", item.ID, item.DealerName, item.Address, dealer.DealerEmailId, dealer.DealerPhoneNumber, dealer.DealerStatus, dealer.DealerProductCategory);


                    Console.WriteLine("******************************************************************************");

                }
            }

            catch (System.Exception)
            {

                throw;
            }
        }
	
        }
    }

       
    
