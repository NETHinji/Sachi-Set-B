﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerRecords.EntityLayer
{
    [Serializable]
    public class Dealer
    {
        
       
            private string _DealerID;

            public string DealerID
            {
                get { return _DealerID; }
                set { _DealerID = value; }
            }
            private string _DealerName;

            public string DealerName
            {
                get { return _DealerName; }
                set { _DealerName = value; }
            }
            private string _DealerAddress;

            public string DealerAddress
            {
                get { return _DealerAddress; }
                set { _DealerAddress = value; }
            }

            private string _ProductCategory;

            public string ProductCategory
        {
                get { return _ProductCategory; }
                set { _ProductCategory = value; }
            }

            private long _DealerPhoneNo;

            public long DealerPhoneNo
        {
                get { return _DealerPhoneNo; }
                set { _DealerPhoneNo = value; }
            }

            private string _DealerEmailID;

            public string DealerEmailID
        {
                get { return _DealerEmailID; }
                set { _DealerEmailID = value; }
            }

            public Dealer()
            {
            DealerID = string.Empty;
            DealerName = string.Empty;
            DealerAddress = string.Empty;
            ProductCategory = string.Empty;
            DealerEmailID = string.Empty;
           
    }
        public DealerStatus1 DealerStatus;
        public ProductCategory1 DealerProductCategory;
        public enum DealerStatus1
        { Active = 1, InActive = 2 }
        public enum ProductCategory1
        { Grocery = 1, Bakery_product = 2, Vegetables = 3, Fruits = 4 }
    }
}
