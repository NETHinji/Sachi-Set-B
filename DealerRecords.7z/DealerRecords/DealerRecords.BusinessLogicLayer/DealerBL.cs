﻿using DealerRecords.DataAccessLayer;
using DealerRecords.EntityLayer;
using DealerRecords.ExceptionLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DealerRecords.BusinessLogicLayer
{
    public class DealerBL
    {
        static bool invalid = false;
        public static List<string> productList = new List<string>() { "Grocery", "Bakery_product ", "Vegetables", "Fruits" };

        private static bool ValidateDealer(Dealer dealer)
        {

            StringBuilder exceptionMessage = new StringBuilder();

            //string x = dealer.DealerID.Substring(2, 4);
            bool returnVal = true;
            if (!(Regex.IsMatch(dealer.DealerID, "([D]{1}[L]{1}[0-9]{4})")))
            {
                returnVal = false;
                exceptionMessage.Append(Environment.NewLine + "Invalid DealerID");
            }
            if (!Regex.Match(Convert.ToString(dealer.DealerPhoneNo), @"([7-9]{1}[0-9]{9})$").Success)
            {
                returnVal = false;
                exceptionMessage.Append(Environment.NewLine + "Invalid Contact....10 digit Contact no required Starting with7,8 or 9");
            }
            if (!Regex.IsMatch(dealer.DealerEmailID, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
            {
                returnVal = false;
                exceptionMessage.Append(Environment.NewLine + "Invalid Email ID");
            }
            if (productList.Contains(dealer.ProductCategory))
            {
                returnVal = false;
                exceptionMessage.Append(Environment.NewLine + "Invalid Product");
            }
            if (!returnVal)
                throw new DealerException(exceptionMessage.ToString());
            return returnVal;
        }
        public static bool AddDealerBL(Dealer newdealer)
        {
            bool returnVal = false;
            try
            {
                if (ValidateDealer(newdealer))
                    returnVal = new DealerDAL().AddDealerDAL(newdealer);
            }
            catch (System.Exception ex)
            {
                throw new DealerException(ex.Message);
            }
            return returnVal;
        }

        public static List<Dealer> SearchDealerBL(string searchDealerProduct)
        {
            List<Dealer> AddDealerDAL = null;
            try
            {
                AddDealerDAL = new DealerDAL().SearchDealerDAL(searchDealerProduct);
            }
            catch (System.Exception ex)
            {
                throw new DealerException(ex.Message);
            }
            return AddDealerDAL;
        }

        public static void SaveObject()
        {
            try
            {
                DealerDAL.SaveObjectDAL();
            }
            catch (System.Exception ex)
            {
                throw new DealerException(ex.Message);
            }
        }

        public static void ReloadList(string path)
        {
            try
            {
                DealerDAL.OpenObjectDAL(path);
            }
            catch (System.Exception ex)
            {
                throw new DealerException(ex.Message);
            }
        }
    }
}
