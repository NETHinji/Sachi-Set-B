﻿using DealerRecords.EntityLayer;
using DealerRecords.ExceptionLayer;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace DealerRecords.DataAccessLayer
{
    public class DealerDAL
    {
        public static List<Dealer> dealerList = new List<Dealer>();

        public bool AddDealerDAL(Dealer newDealer)
        {
            bool returnVal = false;
            try
            {
                dealerList.Add(newDealer);
                returnVal = true;
            }
            catch (System.Exception ex)
            {
                throw new DealerException(ex.Message);
            }
            return returnVal;
        }

        public List<Dealer> SearchDealerDAL(string DealerProductCategory)
        {
            List<Dealer> returnDealer = null;
            try
            {
                returnDealer = dealerList.FindAll(dealer => dealer.ProductCategory == DealerProductCategory);
            }
            catch (System.Exception ex)
            {
                throw new DealerException(ex.Message);
            }
            return returnDealer;
        }

        private static List<Dealer> GetAllDealersDAL() => dealerList;

        public static void SaveObjectDAL()
        {
            List<Dealer> dealerList = GetAllDealersDAL();
            using (System.IO.FileStream fs = new FileStream(@"D:\Users\Span\files\obj.dat", FileMode.Create))
            {
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(fs, dealerList);
            }
        }

        public static void OpenObjectDAL(String path)
        {
            using (FileStream fs = new FileStream(@path, FileMode.Open))
            {
                BinaryFormatter bf = new BinaryFormatter();
                dealerList = (List<Dealer>)bf.Deserialize(fs);
            }
        }
    }
}
