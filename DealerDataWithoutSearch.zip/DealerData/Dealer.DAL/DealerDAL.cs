﻿using Dealer.Entity;
using Dealer.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dealer.DAL
{
    public class DealerDAL
    {
        public static List<DealerEntity> dealers = new List<DealerEntity>();
        public bool AddDAL(DealerEntity dealerEntity)
        {

            bool IsDealerAdded = false;
            try
            {
                dealers.Add(dealerEntity);
                IsDealerAdded = true;

            }
            catch (DealerException)
            {
                Console.WriteLine("Error at DAL");
                throw;

            }
            return IsDealerAdded;

        }

        public List<DealerEntity> GetAllEmployeeDAL()
        {
            return dealers;
        }

        public List<DealerEntity> SearchByCategory(string category)
        {
            List<DealerEntity> Searched = new List<DealerEntity>();
            foreach (var item in dealers)
            {
                Searched.Add(dealers.Find(guest => guest.DealerProductCategory.Equals(category)));
            }
            return Searched;
        }
    }
    
}
