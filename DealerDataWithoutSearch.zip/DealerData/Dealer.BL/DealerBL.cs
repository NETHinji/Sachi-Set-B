﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Dealer.DAL;
using Dealer.Entity;
using Dealer.Exception;

namespace Dealer.BL
{
    public class DealerBL
    {
        static List<DealerEntity> dealers = new List<DealerEntity>();
        public   bool AddBl(DealerEntity dealerEntity)
        {




            bool IsvalidDealer = false;


            IsvalidDealer = Isvalid(dealerEntity);
            if (IsvalidDealer)
            {
                DealerDAL dealerDAL = new DealerDAL();
                bool Valid = dealerDAL.AddDAL(dealerEntity);
                return Valid;
            }
            else
            {
                return IsvalidDealer;
            }

        }

        private  bool Isvalid(DealerEntity dealerEntity)
        {
            try
            {


                List<DealerEntity.Status> statuses = new List<DealerEntity.Status>();
                foreach (DealerEntity.Status item in Enum.GetValues(typeof(Dealer.Entity.DealerEntity.Status)))
                {
                    statuses.Add(item);
                    // Console.WriteLine(item);
                }


                List<DealerEntity.Category> categories = new List<DealerEntity.Category>();
                foreach (DealerEntity.Category item1 in Enum.GetValues(typeof(Dealer.Entity.DealerEntity.Category)))
                {
                    categories.Add(item1);
                    // Console.WriteLine(item);
                }


                bool validate = true;
                //if(!(e.ID.StartsWith("C")&& e.ID.Substring(1, 4).All(char.IsDigit)))
                //{
                //    validate = false;
                //    Console.WriteLine("Enter valid ID ");
                //}

                if (dealerEntity.DealerPhoneNumber.Length != 10)
                {
                    validate = false;
                    Console.WriteLine("Mobile number shoult be of 10-digit");
                }

                if (!(Regex.IsMatch(dealerEntity.DealerPhoneNumber, "([8-9-7]{1}[0-9]{9})")))
                {
                    validate = false;
                    Console.WriteLine("Mobile number should start with 8 or 9 or 7");
                }

                if (!(Regex.IsMatch(dealerEntity.DealerEmailId, @"([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)
                   |(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)")))
                {
                    validate = false;
                    Console.WriteLine("Invalid email number");
                }

                //if (!dealerEntity.DealerStatus.Equals(DealerEntity.Status.on) || !dealerEntity.DealerStatus.Equals(DealerEntity.Status.off))
                //{
                //    validate = false;
                //}

                //if (!dealerEntity.DealerProductCategory.Equals(DealerEntity.Category.BakeryProduct) || !dealerEntity.DealerProductCategory.Equals(DealerEntity.Category.Fruits) || !dealerEntity.DealerProductCategory.Equals(DealerEntity.Category.Grocery) || !dealerEntity.DealerProductCategory.Equals(DealerEntity.Category.Vagetables))
                //{
                //    validate = false;
                //}

                return validate;
            }
            catch (DealerException)
            {
                throw;
            }
        }

      

        public static List<DealerEntity> ShowBL(DealerEntity dealer)
        {

            DealerDAL dealerDAL = new DealerDAL();
            dealers = dealerDAL.GetAllEmployeeDAL();
            return dealers;
        }



        public static List<DealerEntity> SearchGuestBL(string Category)
        {
            DealerDAL dealerDAL = new DealerDAL();
            List<DealerEntity> dealerEntities = new List<DealerEntity>();
            dealerEntities = dealerDAL.SearchByCategory(Category);
            return dealerEntities;
        }

    }
}
