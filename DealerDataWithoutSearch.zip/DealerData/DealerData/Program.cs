﻿using Dealer.BL;
using Dealer.Entity;
using Dealer.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerData
{
    class Program
    {
        static void Main(string[] args)
        {
            DealerEntity dealer = new DealerEntity();
            //List<EmployeeEntity.Department1> departments = new List<EmployeeEntity.Department1>();
            //foreach (EmployeeEntity.Department1 item in Enum.GetValues(typeof(Employee.Entity.EmployeeEntity.Department1)))
            //{
            //    departments.Add(item);
            //    // Console.WriteLine(item);
            //}
            //List<EmployeeEntity> employees1 = new List<EmployeeEntity>();

            int ch = 0;
            do
            {
                ch = Convert.ToInt32(Console.ReadLine());
                try
                {
                    switch (ch)
                    {
                        case 1:

                            AddEmp(dealer);


                            break;

                        case 2:
                            List<DealerEntity> dealers = DealerBL.ShowBL(dealer);
                          
                            Console.WriteLine("******************************************************************************");
                            Console.WriteLine("DealerId\t DealerName\t DealerAddress\t DealerEmailID\t Dealer Phone Number\t Dealer Status\t Dealer Category");
                            Console.WriteLine("******************************************************************************");
                            foreach (DealerEntity employee in dealers)
                            {
                                
                                Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}", dealer.ID,dealer.DealerName,dealer.Address,dealer.DealerEmailId,dealer.DealerPhoneNumber,dealer.DealerStatus,dealer.DealerProductCategory);
                               
                            }
                            Console.WriteLine("******************************************************************************");


                            break;

                        case 3:

                            try
                            {
                                string Category;
                                Console.WriteLine("Enter Category to Search:");
                                Category = Console.ReadLine();
                                //int c = 0;

                                List<DealerEntity> dealers1 = DealerBL.SearchGuestBL(Category);
                                Console.WriteLine(dealers1.Count);
                                foreach (var item in dealers1)
                                {
                                    Console.WriteLine("******************************************************************************");
                                    Console.WriteLine("DealerId\t DealerName\t DealerAddress\t DealerEmailID\t Dealer Phone Number\t Dealer Status\t Dealer Category");
                                    Console.WriteLine("******************************************************************************");
                                   

                                        Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}", dealer.ID, dealer.DealerName, dealer.Address, dealer.DealerEmailId, dealer.DealerPhoneNumber, dealer.DealerStatus, dealer.DealerProductCategory);

                                    
                                    Console.WriteLine("******************************************************************************");

                                }


                            }
                            catch (DealerException ex)
                            {
                                Console.WriteLine(ex.Message);
                            }
                            break;




                    }
                }
                catch (DealerException ex)
                {
                    Console.WriteLine(ex.Message);
                }





            } while (ch != 0);



        }

        private static void AddEmp(DealerEntity dealer)
        {
            try
            {

                Random random = new Random();
                dealer.ID = random.Next(1000, 9000).ToString();
                dealer.DealerName = Console.ReadLine();
                dealer.Address = Console.ReadLine();
                dealer.DealerEmailId = Console.ReadLine();
                dealer.DealerPhoneNumber = Console.ReadLine();
                dealer.DealerStatus = Console.ReadLine();
                dealer.DealerProductCategory = Console.ReadLine();
                DealerBL dealerBL = new DealerBL();
                bool Added = dealerBL.AddBl(dealer);
                if (Added)
                {
                    Console.WriteLine("Added Successfully");
                }
                else
                {
                    Console.WriteLine("Can't Added");
                }

            }
            catch (DealerException)
            {
                throw;
            }
        }
    }
}
    


