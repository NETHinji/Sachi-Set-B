﻿using System;
using System.Runtime.Serialization;

namespace Dealer.Exception
{
    [Serializable]
    public class DealerException : System.Exception
    {
        public DealerException()
        {
        }

        public DealerException(string message) : base(message)
        {
        }

        public DealerException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected DealerException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}