﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dealer.Entity
{
    public class DealerEntity
    {
        public string ID { get; set; }
        public string DealerName { get; set; }
        public string Address { get; set; }
        public string DealerEmailId { get; set; }
        public string DealerPhoneNumber { get; set; }
        public string DealerStatus { get; set; }
        public string DealerProductCategory { get; set; }

        public enum Status
        {
            on, off
        }
        public enum Category
        {
            Grocery, BakeryProduct, Vagetables, Fruits
        }
    }
    
}
