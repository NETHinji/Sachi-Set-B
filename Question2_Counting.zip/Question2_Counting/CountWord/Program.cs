﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CountWord
{
    class Program
    {
        static void Main(string[] args)
        {
            string str;
            int  word, l;
            Console.Write("Enter String to count: ");
            str = Console.ReadLine();
            

            l = 0;
            word = 1;

            /* loop till end of string */
            while (l <= str.Length - 1)
            {
                /* check whether the current character is white space or new line or tab character*/
                if (str[l] == ' ' || str[l] == '\n' || str[l] == '\t')
                {
                    word++;
                }

                l++;
            }

            Console.Write("Total number of words in the string is : {0}\n", word);
            Console.ReadKey();
        }
    }
    }

